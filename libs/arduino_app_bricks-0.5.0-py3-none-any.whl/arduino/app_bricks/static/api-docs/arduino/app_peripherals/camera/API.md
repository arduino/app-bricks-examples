# camera API Reference

## Index

- Class `Camera`
- Class `BaseCamera`
- Class `V4LCamera`
- Class `IPCamera`
- Class `WebSocketCamera`
- Class `CameraError`
- Class `CameraConfigError`
- Class `CameraOpenError`
- Class `CameraReadError`
- Class `CameraTransformError`

---

## `Camera` class

```python
class Camera()
```

Unified Camera class that can be configured for different camera types.

This class serves as both a factory and a wrapper, automatically creating
the appropriate camera implementation based on the provided configuration.

Supports:
    - V4L Cameras (local cameras connected to the system), the default
    - IP Cameras (network-based cameras via RTSP, HLS)
    - WebSocket Cameras (input video streams via WebSocket client)

Note: constructor arguments (except those in signature) must be provided in
keyword format to forward them correctly to the specific camera implementations.


---

## `BaseCamera` class

```python
class BaseCamera(resolution: tuple[int, int], fps: int, adjustments: Callable[[np.ndarray], np.ndarray])
```

Abstract base class for camera implementations.

This class defines the common interface that all camera implementations must follow,
providing a unified API regardless of the underlying camera protocol or type.

### Parameters

- **resolution** (*tuple*) (optional): Resolution as (width, height). None uses default resolution.
- **fps** (*int*): Frames per second to capture from the camera.
- **adjustments** (*callable*) (optional): Function or function pipeline to adjust frames that takes
a numpy array and returns a numpy array. Default: None

### Methods

#### `start()`

Start the camera capture.

#### `stop()`

Stop the camera and release resources.

#### `capture()`

Capture a frame from the camera, respecting the configured FPS.

##### Returns

-: Numpy array or None if no frame is available.

#### `stream()`

Continuously capture frames from the camera.

This is a generator that yields frames continuously while the camera is started.
Built on top of capture() for convenience.

##### Returns

- (*np.ndarray*): Video frames as numpy arrays.

#### `is_started()`

Check if the camera is started.


---

## `V4LCamera` class

```python
class V4LCamera(device: str | int, resolution: tuple[int, int], fps: int, adjustments: Callable[[np.ndarray], np.ndarray])
```

V4L (Video4Linux) camera implementation for USB and local cameras.

This class handles USB cameras and other V4L-compatible devices on Linux systems.
It supports both device indices and device paths.

### Parameters

- **device**: Camera identifier - can be:
- int: Camera index (e.g., 0, 1)
- str: Camera index as string or device path
- **resolution** (*tuple*) (optional): Resolution as (width, height). None uses default resolution.
- **fps** (*int*) (optional): Frames per second to capture from the camera. Default: 10.
- **adjustments** (*callable*) (optional): Function or function pipeline to adjust frames that takes
a numpy array and returns a numpy array. Default: None


---

## `IPCamera` class

```python
class IPCamera(url: str, username: str | None, password: str | None, timeout: int, resolution: tuple[int, int], fps: int, adjustments: Callable[[np.ndarray], np.ndarray])
```

IP Camera implementation for network-based cameras.

Supports RTSP, HTTP, and HTTPS camera streams.
Can handle authentication and various streaming protocols.

### Parameters

- **url**: Camera stream URL (i.e. rtsp://..., http://..., https://...)
- **username**: Optional authentication username
- **password**: Optional authentication password
- **timeout**: Connection timeout in seconds
- **resolution** (*tuple*) (optional): Resolution as (width, height). None uses default resolution.
- **fps** (*int*): Frames per second to capture from the camera.
- **adjustments** (*callable*) (optional): Function or function pipeline to adjust frames that takes
a numpy array and returns a numpy array. Default: None


---

## `WebSocketCamera` class

```python
class WebSocketCamera(host: str, port: int, timeout: int, frame_format: Literal['binary', 'base64', 'json'], resolution: tuple[int, int], fps: int, adjustments: Callable[[np.ndarray], np.ndarray])
```

WebSocket Camera implementation that hosts a WebSocket server.

This camera acts as a WebSocket server that receives frames from connected clients.
Only one client can be connected at a time.

Clients must encode video frames in one of these formats:
- JPEG
- PNG
- WebP
- BMP
- TIFF

The frames can be serialized in one of the following formats:
- Binary image data
- Base64 encoded images
- JSON messages with image data

### Parameters

- **host** (*str*): Host address to bind the server to (default: "0.0.0.0")
- **port** (*int*): Port to bind the server to (default: 8080)
- **timeout** (*int*): Connection timeout in seconds (default: 10)
- **frame_format** (*str*): Expected frame format from clients ("binary", "base64", "json") (default: "binary")
- **resolution** (*tuple*) (optional): Resolution as (width, height). None uses default resolution.
- **fps** (*int*): Frames per second to capture from the camera.
- **adjustments** (*callable*) (optional): Function or function pipeline to adjust frames that takes
a numpy array and returns a numpy array. Default: None


---

## `CameraError` class

```python
class CameraError()
```

Base exception for camera-related errors.


---

## `CameraConfigError` class

```python
class CameraConfigError()
```

Exception raised when camera configuration is invalid.


---

## `CameraOpenError` class

```python
class CameraOpenError()
```

Exception raised when the camera cannot be opened.


---

## `CameraReadError` class

```python
class CameraReadError()
```

Exception raised when reading from camera fails.


---

## `CameraTransformError` class

```python
class CameraTransformError()
```

Exception raised when frame transformation fails.


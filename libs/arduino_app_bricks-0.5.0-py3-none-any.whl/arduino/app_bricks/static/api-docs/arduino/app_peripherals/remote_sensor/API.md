# remote_sensor API Reference

## Index

- Class `RemoteSensor`
- Class `RemoteSensorOpenError`
- Class `RemoteSensorReadError`
- Class `RemoteSensorConfigError`
- Class `RemoteSensorDisconnectedError`

---

## `RemoteSensor` class

```python
class RemoteSensor(port: int, timeout: int, data_format: Literal['json', 'csv', 'binary'], auto_reconnect: bool)
```

RemoteSensor implementation that hosts a WebSocket server.

This sensor acts as a WebSocket server that receives IoT telemetry data from connected clients.
Only one client can be connected at a time.

Clients can send data in JSON, CSV, or binary format. Each message is passed to the registered
callback via the on_datapoint method.

### Parameters

- **port** (*int*): Port to bind the server to (default: 8080)
- **timeout** (*int*): Connection timeout in seconds (default: 3)
- **data_format** (*str*): Expected data format from clients (default: "json")
- "json": JSON object format. Callback receives the parsed dict directly.
- "csv": CSV format with ",", "\t", or " " as field separators and CRLF or LF
  as line separator. Double quotes for escaping strings. Each line is a sensor
  reading. Callback receives {"csv": "line_content"}.
- "binary": Raw binary data. Callback receives {"binary": numpy_array}.
- **auto_reconnect** (*bool*) (optional): Enable automatic reconnection on failure. Default: True.

### Methods

#### `status()`

Read-only property for camera status.

#### `url()`

Return the WebSocket server address.

#### `start()`

Start the WebSocket server.

#### `stop()`

Stop the WebSocket server.

#### `on_datapoint(callback: Callable[[dict], None])`

Register a callback function to be called when a datapoint is received.

The callback function will be called with a single argument: a dictionary containing
the parsed data. The format of the dictionary depends on the data_format setting:

- "json" format: The parsed JSON object is passed directly as a dict.
- "csv" format: {"csv": "line_content"} where line_content is the CSV line string.
- "binary" format: {"binary": numpy_array} where numpy_array contains the raw bytes as uint8.

##### Parameters

- **callback** (*Callable*): A function that takes a dict and returns None.

#### `is_started()`

Check if the sensor is started and running.

#### `on_status_changed(callback: Callable[[str, dict], None] | None)`

Registers or removes a callback to be triggered on camera lifecycle events.

When a camera status changes, the provided callback function will be invoked.
If None is provided, the callback will be removed.

##### Parameters

- **callback** (*Callable[[str, dict], None]*): A callback that will be called every time the
camera status changes with the new status and any associated data. The status names
depend on the actual camera implementation being used. Some common events are:
- 'connected': The camera has been reconnected.
- 'disconnected': The camera has been disconnected.
- 'streaming': The stream is streaming.
- 'paused': The stream has been paused and is temporarily unavailable.
- **callback** (*None*): To unregister the current callback, if any.

##### Examples

```python
def on_status(status: str, data: dict):
    print(f"Camera is now: {status}")
    print(f"Data: {data}")
    # Here you can add your code to react to the event

camera.on_status_changed(on_status)
```

---

## `RemoteSensorOpenError` class

```python
class RemoteSensorOpenError()
```

Exception raised when the remote sensor server cannot be opened.


---

## `RemoteSensorReadError` class

```python
class RemoteSensorReadError()
```

Exception raised when reading from remote sensor fails.


---

## `RemoteSensorConfigError` class

```python
class RemoteSensorConfigError()
```

Exception raised when remote sensor configuration is invalid.


---

## `RemoteSensorDisconnectedError` class

```python
class RemoteSensorDisconnectedError()
```

Exception raised when the remote sensor client is disconnected.


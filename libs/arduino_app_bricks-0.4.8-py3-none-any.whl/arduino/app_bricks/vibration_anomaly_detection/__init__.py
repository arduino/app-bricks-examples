# SPDX-FileCopyrightText: Copyright (C) 2025 ARDUINO SA <http://www.arduino.cc>
#
# SPDX-License-Identifier: MPL-2.0

import threading
import queue
import inspect
import numpy as np
import time
from typing import Iterable
from arduino.app_internal.core import EdgeImpulseRunnerFacade
from arduino.app_utils import Logger, SlidingWindowBuffer, brick

logger = Logger("AnomalyDetection")

@brick
class VibrationAnomalyDetection(EdgeImpulseRunnerFacade):
    """This Anomaly Detection module classifies accelerometr sensor data to detect vibration anomalies based on a pre-trained model."""

    def __init__(self, anomaly_detection_threshold: float = 1.0):
        """Initialize the VibrationAnomalyDetection module.

        Args:
            anomaly_detection_threshold (float): Confidence level for the anomaly score. Default is 1 (absolute value).
        """
        self._anomaly_detection_threshold = anomaly_detection_threshold
        super().__init__()
        model_info = self.get_model_info()
        if not model_info:
            raise ValueError("Failed to retrieve model information. Ensure the EI model runner service is running.")
        if model_info.frequency <= 0 or model_info.input_features_count <= 0:
            raise ValueError("Model parameters are missing or incomplete in the retrieved model information.")
        self._model_info = model_info
        
        self._handler = None # Single handler for anomaly detection
        self._handler_lock = threading.Lock()

        self._buffer = SlidingWindowBuffer(
            window_size=model_info.input_features_count,
            slide_amount=int(model_info.input_features_count)
        )

    def accumulate_samples(self, sensor_samples: Iterable[float]) -> None:
        """Accumulate sensor samples

        Args:
            sensor_samples (Iterable): An iterable of sensor samples (e.g., accelerometer data).
        """
        if not sensor_samples or len(sensor_samples) == 0:
            raise ValueError("Invalid sensor samples. Expected an array with len > 0.")

        # Fill time window buffer with the latest accelerometer samples.
        chunk = np.array(sensor_samples)
        if not self._buffer.push(chunk):
            logger.debug(f"Samples not pushed to the buffer. Buffer is full or has insufficient capacity.")


    def on_anomaly(self, callback: callable):
        """Register a callback function to be invoked when an anomaly is detected.

           Function signature of the callback should be:
               - callback()  # No parameters
               - callback(anomaly_score: float)
               - callback(anomaly_score: float, classification: dict)

        Args:
            callback (callable): a callback function to handle label spotted.

        Raises:
            ValueError: If the sample width is unsupported.
        """

        self._handler_lock.acquire()
        try:
            self._handler = callback
        finally:
            self._handler_lock.release()

    def loop(self):
        """Main loop for anomaly detection, processing sensor data and invoking callbacks when anomalies are detected."""
        try:
            features = self._buffer.pull()
            if features is None or len(features) == 0:
                return

            ret = super().infer_from_features(features[:int(self._model_info.input_features_count)].flatten().tolist())
            logger.debug(f"Inference result: {ret}")
            spotted_anomaly = self._extract_anomaly_score(ret)
            if spotted_anomaly is not None:
                if spotted_anomaly >= self._anomaly_detection_threshold and self._handler is not None:
                    callback = self._handler
                    if callback is not None and inspect.isfunction(callback):
                        logger.debug(f"Invoking callback handler for anomaly.")
                        callback_signature = inspect.signature(callback)  # Validate callback signature
                        if len(callback_signature.parameters) == 0:
                            callback()
                        elif len(callback_signature.parameters) >= 1:
                            if len(callback_signature.parameters) == 1:
                                # If the callback expects one parameter, pass the anomaly score
                                callback(spotted_anomaly)
                            else:
                                # If the callback expects more than one parameter, try to find a parameter that matches the expected name: "classification"
                                if 'classification' in callback_signature.parameters:
                                    complete_detection = self._extract_classification(ret)
                                    callback(spotted_anomaly, classification=complete_detection)
                        else:
                            logger.error(f"Callback has an unsupported signature. Expected 0 or 1 parameters, got {len(callback_signature.parameters)}.")

        except queue.Empty:
            return
        except queue.ShutDown:
            raise StopIteration()
        except Exception as e:
            logger.error(f"Error {e}")
            time.sleep(1)  # Sleep briefly to avoid tight loop in case of errors

    def start(self):
        """Start the AnomalyDetection module and prepare for motion detection."""
        self._buffer.flush()

    def stop(self):
        """Stop the AnomalyDetection module and release resources."""
        self._clear()

    def _clear(self):
        """Clear the sensor data buffer."""
        self._buffer.flush()
        logger.info(f"Sensor data buffer cleared")

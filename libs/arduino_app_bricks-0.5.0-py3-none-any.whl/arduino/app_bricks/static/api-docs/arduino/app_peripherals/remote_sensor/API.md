# remote_sensor API Reference

## Index

- Class `RemoteSensor`
- Class `RemoteSensorOpenError`
- Class `RemoteSensorReadError`
- Class `RemoteSensorConfigError`
- Class `RemoteSensorDisconnectedError`

---

## `RemoteSensor` class

```python
class RemoteSensor(host: str, port: int, timeout: int, data_format: Literal['json', 'csv', 'binary'])
```

RemoteSensor implementation that hosts a WebSocket server.

This sensor acts as a WebSocket server that receives IoT telemetry data from connected clients.
Only one client can be connected at a time.

Clients can send data in JSON, CSV, or binary format. Each message is passed to the registered
callback via the on_datapoint method.

### Parameters

- **host** (*str*): Host address to bind the server to (default: "0.0.0.0")
- **port** (*int*): Port to bind the server to (default: 8080)
- **timeout** (*int*): Connection timeout in seconds (default: 10)
- **data_format** (*str*): Expected data format from clients (default: "json")
- "json": JSON object format. Callback receives the parsed dict directly.
- "csv": CSV format with ",", "\t", or " " as field separators and CRLF or LF
  as line separator. Double quotes for escaping strings. Each line is a sensor
  reading. Callback receives {"csv": "line_content"}.
- "binary": Raw binary data. Callback receives {"binary": numpy_array}.

### Methods

#### `start()`

Start the WebSocket server.

#### `stop()`

Stop the WebSocket server.

#### `on_datapoint(callback: Callable[[dict], None])`

Register a callback function to be called when a datapoint is received.

The callback function will be called with a single argument: a dictionary containing
the parsed data. The format of the dictionary depends on the data_format setting:

- "json" format: The parsed JSON object is passed directly as a dict.
- "csv" format: {"csv": "line_content"} where line_content is the CSV line string.
- "binary" format: {"binary": numpy_array} where numpy_array contains the raw bytes as uint8.

##### Parameters

- **callback** (*Callable*): A function that takes a dict and returns None.

#### `is_started()`

Check if the sensor is started and running.


---

## `RemoteSensorOpenError` class

```python
class RemoteSensorOpenError()
```

Exception raised when the remote sensor server cannot be opened.


---

## `RemoteSensorReadError` class

```python
class RemoteSensorReadError()
```

Exception raised when reading from remote sensor fails.


---

## `RemoteSensorConfigError` class

```python
class RemoteSensorConfigError()
```

Exception raised when remote sensor configuration is invalid.


---

## `RemoteSensorDisconnectedError` class

```python
class RemoteSensorDisconnectedError()
```

Exception raised when the remote sensor client is disconnected.


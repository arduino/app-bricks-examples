# midi_keyboard API Reference

## Index

- Class `MidiMessage`
- Class `MIDIKeyboardException`
- Class `MIDIKeyboard`
- Class `AlsaSeqPort`
- Class `MIDIProfile`
- Class `AkaiMPKMiniPlusProfile`
- Class `AkaiMPCMiniProfile`
- Class `NIMaschineMikroProfile`
- Class `LaunchpadMiniProfile`
- Class `GeneralMIDIDrumMapProfile`
- Function `profiles.load_profile`
- Function `profiles.list_available_profiles`
- Function `profiles.detect_profile`

---

## `MidiMessage` class

```python
class MidiMessage(msg_type: str)
```

Minimal MIDI message container (compatible with mido.Message interface).


---

## `MIDIKeyboardException` class

```python
class MIDIKeyboardException()
```

Custom exception for MIDI keyboard errors.


---

## `MIDIKeyboard` class

```python
class MIDIKeyboard(device: Optional[str], channel: Optional[int], profile: Optional[str])
```

MIDI keyboard/controller input peripheral for Linux/ALSA.

Handles MIDI input from USB MIDI devices including keyboards, drum pads,
and control surfaces. Provides callbacks for note events, control changes,
and pitch bend.

Uses direct ALSA device access (/dev/snd/midiC*D*) without external dependencies.
Designed for Arduino UNO Q and other Linux boards with ALSA support.

### Parameters

- **device** (*str*) (optional): MIDI device name or USB_MIDI_1/2 macro.
If None, uses the first available MIDI input.
- **channel** (*int*) (optional): MIDI channel to filter (1-16).
If None, receives from all channels.
- **profile** (*str*) (optional): Controller profile name for semantic mapping.
If None, uses generic/raw MIDI mode.

### Raises

- **MIDIKeyboardException**: If no MIDI device is found or cannot be opened.

### Methods

#### `list_usb_devices()`

List available MIDI input devices (ALSA raw MIDI).

##### Returns

-: List of dicts with 'hw_name' (hw:X,Y) and 'friendly_name' (descriptive name)

#### `start()`

Open MIDI port and start listening for messages.

#### `stop()`

Stop listening and close MIDI port.

#### `is_connected()`

Check if MIDI device is still connected and running.

##### Returns

-: True if device is connected and listening thread is alive

#### `on_note_on(callback: Callable, note: Optional[int])`

Register callback for note on events.

##### Parameters

- **callback**: Callback function(note, velocity) or function(velocity) if note specified
- **note**: Specific note number (0-127). If None, callback receives all note on events.

##### Examples

```python
# All notes
midi.on_note_on(lambda note, vel: print(f"Note {note}: {vel}"))

# Specific note
midi.on_note_on(lambda vel: print(f"C4: {vel}"), note=60)
```
#### `on_note_off(callback: Callable, note: Optional[int])`

Register callback for note off events.

##### Parameters

- **callback**: Callback function(note, velocity) or function(velocity) if note specified
- **note**: Specific note number (0-127). If None, callback receives all note off events.

#### `on_control_change(callback: Callable, control: Optional[int])`

Register callback for control change events.

##### Parameters

- **callback**: Callback function(control, value) or function(value) if control specified
- **control**: Specific CC number (0-127). If None, callback receives all CC events.

##### Examples

```python
# All CCs
midi.on_control_change(lambda cc, val: print(f"CC {cc}: {val}"))

# Specific CC
midi.on_control_change(lambda val: print(f"Modwheel: {val}"), control=1)
```
#### `on_pitch_bend(callback: Callable)`

Register callback for pitch bend events.

##### Parameters

- **callback**: Callback function(value) where value is -8192 to +8191

##### Examples

```python
midi.on_pitch_bend(lambda val: print(f"Pitch bend: {val}"))
```
#### `on_aftertouch(callback: Callable)`

Register callback for aftertouch (channel pressure) events.

##### Parameters

- **callback**: Callback function(value) where value is 0-127

#### `on_pad(pad_name: str, callback: Callable)`

Register callback for semantic pad name (requires profile).

##### Parameters

- **pad_name**: Semantic pad name from profile (e.g., "pad_1", "kick")
- **callback**: Callback function(velocity)

##### Raises

- **MIDIKeyboardException**: If no profile is loaded

##### Examples

```python
midi = MIDIKeyboard(profile="akai_mpc_mini")
midi.on_pad("pad_1", lambda vel: print(f"Pad 1: {vel}"))
```
#### `on_knob(knob_name: str, callback: Callable)`

Register callback for semantic knob name (requires profile).

##### Parameters

- **knob_name**: Semantic knob name from profile (e.g., "knob_1", "filter_cutoff")
- **callback**: Callback function(value)

##### Raises

- **MIDIKeyboardException**: If no profile is loaded

##### Examples

```python
midi = MIDIKeyboard(profile="akai_mpk_mini_plus")
midi.on_knob("knob_1", lambda val: print(f"Knob 1: {val}"))
```
#### `note_to_frequency(note: int)`

Convert MIDI note number to frequency in Hz.

##### Parameters

- **note**: MIDI note number (0-127)

##### Returns

-: Frequency in Hz

##### Examples

```python
freq = MIDIKeyboard.note_to_frequency(69)  # A4 = 440 Hz
```
#### `frequency_to_note(frequency: float)`

Convert frequency in Hz to nearest MIDI note number.

##### Parameters

- **frequency**: Frequency in Hz

##### Returns

-: MIDI note number (0-127)

#### `get_profile_info()`

Get current profile information.

##### Returns

-: Profile info dict or None if no profile loaded

#### `list_profiles()`

List available controller profiles.

##### Returns

-: List of profile names


---

## `AlsaSeqPort` class

```python
class AlsaSeqPort(device_name)
```

Minimal ALSA sequencer port wrapper compatible with mido interface.

### Methods

#### `receive(block)`

Read MIDI message from device (compatible with mido interface).

#### `close()`

Close the ALSA device.


---

## `MIDIProfile` class

```python
class MIDIProfile()
```

Base class for MIDI controller profiles.

Profiles provide semantic mapping between raw MIDI note/CC numbers
and human-readable control names (e.g., note 36 -> "kick", CC 70 -> "knob_1").


---

## `AkaiMPKMiniPlusProfile` class

```python
class AkaiMPKMiniPlusProfile()
```

Profile for Akai MPK Mini Plus keyboard controller.


---

## `AkaiMPCMiniProfile` class

```python
class AkaiMPCMiniProfile()
```

Profile for Akai MPC Mini / MPC Mini Play drum pad controller.


---

## `NIMaschineMikroProfile` class

```python
class NIMaschineMikroProfile()
```

Profile for Native Instruments Maschine Mikro MK3 controller.

Note: This profile is for MIDI mode. In Maschine mode, the controller
uses proprietary protocol and will not send standard MIDI messages.


---

## `LaunchpadMiniProfile` class

```python
class LaunchpadMiniProfile()
```

Profile for Novation Launchpad Mini grid controller.


---

## `GeneralMIDIDrumMapProfile` class

```python
class GeneralMIDIDrumMapProfile()
```

Profile using General MIDI drum map for semantic naming.


---

## `profiles.load_profile` function

```python
def load_profile(profile_name: str)
```

Load a MIDI controller profile by name.

### Parameters

- **profile_name**: Profile identifier (e.g., "akai_mpc_mini")

### Returns

-: MIDIProfile instance

### Raises

- **ValueError**: If profile name is unknown


---

## `profiles.list_available_profiles` function

```python
def list_available_profiles()
```

List all available profile names.

### Returns

-: List of profile name strings


---

## `profiles.detect_profile` function

```python
def detect_profile(device_name: str)
```

Auto-detect controller profile from MIDI device name.

### Parameters

- **device_name**: MIDI device name from mido.get_input_names()

### Returns

-: Profile name (best match or "generic")


# microphone API Reference

## Index

- Class `Microphone`
- Class `BaseMicrophone`
- Class `ALSAMicrophone`
- Class `WebSocketMicrophone`
- Class `MicrophoneError`
- Class `MicrophoneConfigError`
- Class `MicrophoneOpenError`
- Class `MicrophoneReadError`

---

## `Microphone` class

```python
class Microphone()
```

Unified Microphone class that can be configured for different microphone types.

This class serves as both a factory and a wrapper, automatically creating
the appropriate microphone implementation based on the provided configuration.

Supports:
    - ALSA Microphones (local microphones connected to the system via ALSA)
    - WebSocket Microphones (input audio streams via WebSocket client)

Note: constructor arguments (except those in signature) must be provided in
keyword format to forward them correctly to the specific microphone implementations.
Refer to the documentation of each microphone type for available parameters.


---

## `BaseMicrophone` class

```python
class BaseMicrophone(sample_rate: int, channels: int, format: str, chunk_size: int)
```

Abstract base class for microphone implementations.

This class defines the common interface that all microphone implementations must follow,
providing a unified API regardless of the underlying audio capture protocol or type.

The output is always a numpy array with the ALSA PCM format.

### Parameters

- **sample_rate** (*int*): Sample rate in Hz (default: 16000).
- **channels** (*int*): Number of audio channels (default: 1).
- **format** (*str*): Audio format in ALSA PCM notation (default: "S16_LE").
- **chunk_size** (*int*): Number of frames per chunk (default: 1024).

### Methods

#### `start()`

Start the microphone capture.

#### `stop()`

Stop the microphone and release resources.

#### `capture()`

Capture an audio chunk from the microphone.

##### Returns

-: Numpy array in ALSA PCM format or None if no audio is available.

#### `stream()`

Continuously capture audio chunks from the microphone.

This is a generator that yields audio chunks continuously while the microphone is started.

##### Returns

- (*np.ndarray*): Audio chunks as numpy arrays.

#### `record(duration: float, timeout_factor: float)`

Record audio for a specified duration and return as raw PCM format.

##### Parameters

- **duration** (*float*): Recording duration in seconds.
- **timeout_factor** (*float*): Maximum wall-clock time as multiple of duration (default: 2.0).
This prevents indefinite blocking when audio source is sparse.

##### Returns

- (*np.ndarray*): Raw audio data in raw ALSA PCM format.

##### Raises

- **MicrophoneOpenError**: If microphone is not started.
- **ValueError**: If duration is not positive.
- **TimeoutError**: If recording takes longer than duration * timeout_factor.

#### `record_wav(duration: float, timeout_factor: float)`

Record audio for a specified duration and return as WAV format.

##### Parameters

- **duration** (*float*): Recording duration in seconds.
- **timeout_factor** (*float*): Maximum wall-clock time as multiple of duration (default: 2.0).
This prevents indefinite blocking when audio source is sparse.

##### Returns

- (*np.ndarray*): Raw audio data in WAV format as numpy array.

##### Raises

- **MicrophoneOpenError**: If microphone is not started.
- **ValueError**: If duration is not positive.
- **TimeoutError**: If recording takes longer than duration * timeout_factor.

#### `is_started()`

Check if the microphone is started.


---

## `ALSAMicrophone` class

```python
class ALSAMicrophone(device: str | int, sample_rate: int, channels: int, format: str, chunk_size: int)
```

ALSA (Advanced Linux Sound Architecture) microphone implementation.

This class handles local audio capture devices on Linux systems using ALSA.
It supports explicit ALSA device names (e.g., "plughw:CARD=USB,DEV=0").

### Parameters

- **device** (*Union[str, int]*): ALSA device identifier. Can be:
- int: Microphone index (e.g., 0, 1) - uses USB microphones list
- str: Microphone index as string (e.g., "0", "1")
- str: ALSA device name (e.g., "plughw:CARD=USB,DEV=0")
- **sample_rate** (*int*): Sample rate in Hz (default: 16000).
- **channels** (*int*): Number of audio channels (default: 1).
- **format** (*str*): Audio format (default: "S16_LE").
- **chunk_size** (*int*): Number of frames per chunk (default: 1024).

### Raises

- **MicrophoneConfigError**: If the format is not supported.

### Methods

#### `get_volume()`

Get the current volume level of the microphone.

##### Returns

- (*int*): Volume level (0-100). If no mixer is available, returns None.

#### `set_volume(volume: int)`

Set the volume level of the microphone.

##### Parameters

- **volume** (*int*): Volume level (0-100).

##### Raises

- **ValueError**: If the volume is not between 0 and 100.

#### `list_devices()`

Return a list of available ALSA capture devices.

##### Returns

- (*list*): List of ALSA device names.

#### `list_usb_devices()`

Return an ordered list of ALSA device names for available USB microphones (plughw only).

##### Returns

- (*list*): List of USB microphone device names.


---

## `WebSocketMicrophone` class

```python
class WebSocketMicrophone(port: int, timeout: int, audio_format: Literal['binary', 'base64', 'json'], sample_rate: int, channels: int, format: str, chunk_size: int)
```

WebSocket Microphone implementation that hosts a WebSocket server.

This microphone exposes a WebSocket server that receives audio chunks from connected clients.
Only one client can be connected at a time.

Clients must send PCM audio data in one of these formats:
- Binary (raw)
- Base64 encoded
- With JSON envelope

Also, clients are expected to respect the sample rate, channels, format, and chunk size
specified during initialization.

### Parameters

- **port** (*int*): Port to bind the server to (default: 8080)
- **timeout** (*int*): Connection timeout in seconds (default: 10)
- **audio_format** (*str*): Expected audio format from clients ("binary", "base64", "json") (default: "binary")
- **sample_rate** (*int*): Sample rate in Hz (default: 16000)
- **channels** (*int*): Number of audio channels (default: 1)
- **format** (*str*): Audio format (default: "S16_LE")
- **chunk_size** (*int*): Number of frames per chunk (default: 1024). This parameter is advisory,
it's sent to clients to suggest an optimal chunk size but clients may ignore it.


---

## `MicrophoneError` class

```python
class MicrophoneError()
```

Base exception for microphone-related errors.


---

## `MicrophoneConfigError` class

```python
class MicrophoneConfigError()
```

Exception raised when microphone configuration is invalid.


---

## `MicrophoneOpenError` class

```python
class MicrophoneOpenError()
```

Exception raised when the microphone cannot be opened.


---

## `MicrophoneReadError` class

```python
class MicrophoneReadError()
```

Exception raised when reading from microphone fails.

